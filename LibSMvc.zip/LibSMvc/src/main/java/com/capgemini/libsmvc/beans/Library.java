package com.capgemini.libsmvc.beans;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Table
@Entity
public class Library {

	@Column
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int libId;
	@Column
	private int libName;
	@OneToMany(mappedBy = "library")
	private List<Book> books;


	public int getLibId() {
		return libId;
	}
	public void setLibId(int libId) {
		this.libId = libId;
	}
	public int getLibName() {
		return libName;
	}
	public void setLibName(int libName) {
		this.libName = libName;
	}

	public List<Book> getBooks() {
		return books;
	}
	public void setBooks(List<Book> books) {
		this.books = books;
	}
	@Override
	public String toString() {
		return "Library [libId=" + libId + ", libName=" + libName + ", books=" + books + "]";
	}

}
