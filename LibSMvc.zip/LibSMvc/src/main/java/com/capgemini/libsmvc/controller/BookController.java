package com.capgemini.libsmvc.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.libsmvc.beans.Book;
import com.capgemini.libsmvc.service.BookService;

@Controller
public class BookController {
	@Autowired
	private BookService bookservice;

	@RequestMapping("/")
	public ModelAndView home() {
		List<Book> listBook = bookservice.getAllbook();
		ModelAndView mav = new ModelAndView("index");
		mav.addObject("listBook", listBook);
		return mav;
	}

	@RequestMapping("/new")
	public String newBookForm(Map<String, Object> model) {
		// Book book = new Book();
		model.put("book", new Book());
		return "addBook";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveBook(@ModelAttribute("book") Book book) {
		bookservice.addBook(book);
		return "redirect:/";
	}

	// @RequestMapping("/edit")
	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public ModelAndView editBook(@RequestParam Integer bookId) {
		ModelAndView mav = new ModelAndView("updateBook");
		Book book = bookservice.SearchBook(bookId);
		mav.addObject("book", book);
		return mav;
	}

	@RequestMapping("/delete")
	public String deleteBook(@RequestParam int bookId) {
		bookservice.deleteBook(bookId);
		return "redirect:/";
	}

	@RequestMapping(value = "/search", method = RequestMethod.POST)
	// @RequestMapping("/search")
	public ModelAndView searchBook(@RequestParam int bookId) {
		ModelAndView mav = new ModelAndView("searchBook");
		Book res = bookservice.SearchBook(bookId);
		mav.addObject("res", res);
		return mav;
	}

}
